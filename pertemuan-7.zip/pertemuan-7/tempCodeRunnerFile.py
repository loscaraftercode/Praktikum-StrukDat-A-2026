de.next
    print("null")
