

katalog = [
    {'nama': 'Belajar Python', 'harga': 75000, 'stok': 5},
    {'nama': 'Struktur Data', 'harga': 95000, 'stok': 3},
    {'nama': 'Algoritma Dasar', 'harga': 60000, 'stok': 8},
]

log_transaksi = []
riwayat_transaksi = set()

level_diskon = (
    (500000, 15),
    (300000, 10),
    (100000, 5),
    (0, 0)
)


def tambah_buku(nama, harga, stok):

    if harga <= 0:
        print("Harga tidak valid")
        return None

    if stok < 0:
        print("Stok tidak valid")
        return None

    buku = {
        "nama": nama,
        "harga": harga,
        "stok": stok
    }

    return buku




def tampilkan_buku(katalog):

    print("\n=== DAFTAR BUKU ===")
    print(f"{'Nama Buku':20} {'Harga':10} {'Stok':5}")
    print("-" * 40)

    for buku in katalog:
        print(f"{buku['nama']:20} {buku['harga']:10} {buku['stok']:5}")



def proses_transaksi(katalog, nama_buku, jumlah_beli):

    for buku in katalog:

        if buku['nama'].lower() == nama_buku.lower():

            if buku['stok'] >= jumlah_beli:

                total = buku['harga'] * jumlah_beli
                buku['stok'] -= jumlah_beli

                print("\nTransaksi berhasil")
                print("Buku :", buku['nama'])
                print("Jumlah :", jumlah_beli)
                print("Total :", total)

                riwayat_transaksi.add(buku['nama'])

                return (buku['nama'], jumlah_beli, total)

            else:
                print("Stok tidak mencukupi")
                return None

    print("Buku tidak ditemukan")
    return None




def hitung_diskon(total_belanja, level_diskon, index=0):

    batas, persen = level_diskon[index]

    if total_belanja >= batas:

        nominal = total_belanja * persen / 100
        total = total_belanja - nominal

        return persen, nominal, total

    else:
        return hitung_diskon(total_belanja, level_diskon, index + 1)




while True:

    print("\n=== PyBook Store ===")
    print("1. Tambah Buku")
    print("2. Tampilkan Semua Buku")
    print("3. Beli Buku")
    print("4. Laporan Penjualan")
    print("5. Keluar")

    menu = input("Pilih menu: ")



    if menu == "1":

        nama = input("Nama buku: ")
        harga = int(input("Harga buku: "))
        stok = int(input("Stok buku: "))

        buku_baru = tambah_buku(nama, harga, stok)

        if buku_baru:
            katalog.append(buku_baru)
            print("Buku berhasil ditambahkan")




    elif menu == "2":

        tampilkan_buku(katalog)



    elif menu == "3":

        nama = input("Masukkan nama buku: ")
        jumlah = int(input("Jumlah beli: "))

        transaksi = proses_transaksi(katalog, nama, jumlah)

        if transaksi:
            log_transaksi.append(transaksi)



    elif menu == "4":

        print("\n=== LOG TRANSAKSI ===")

        total_penjualan = 0

        for t in log_transaksi:
            nama, jumlah, total = t

            print(f"{nama} | jumlah: {jumlah} | total: {total}")

            total_penjualan += total

        persen, nominal, total_bayar = hitung_diskon(total_penjualan, level_diskon)

        print("\nTotal Penjualan :", total_penjualan)
        print("Diskon :", persen, "%")
        print("Nominal Diskon :", int(nominal))
        print("Total Setelah Diskon :", int(total_bayar))

        print("\nRiwayat Buku Terjual:")
        for buku in riwayat_transaksi:
            print("-", buku)



    elif menu == "5":

        print("Terima kasih telah menggunakan PyBook Store")
        break

    else:
        print("Menu tidak tersedia")